import React from "react";
import { NavLink } from "react-router-dom";
import "../css/navbar.css";

function NavBar() {
  return (
    <nav>
      <NavLink to="/home">Home</NavLink>
      <NavLink to="/">Register</NavLink>
      <NavLink to="/login">Login</NavLink>
      <NavLink to="/details">Company Details</NavLink>
    </nav>
  );
}

export default NavBar;
