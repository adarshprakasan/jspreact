import React, { useEffect, useState } from "react";
import axios from "axios";
import "../css/moviesection.css";

function MovieSection() {
  let [movies, setMovies] = useState([]);

  let updateMovie = async () => {
    try {
      let {
        data: { Search },
      } = await axios.get(
        `https://www.omdbapi.com/?s=avengers&apikey=428f8624`
      );
      setMovies(Search);
      console.log(movies);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    updateMovie();
  }, []);

  return (
    <div className="movieList">
      {movies.map((movie) => {
        return (
          <div key={movie.imdbID} className="movieCard">
            <div className="movieImg">
              <img src={movie.Poster} alt="No Img" />
            </div>
            <div className="movieDetails">
              <h1>{movie.Title}</h1>
              <i>{movie.Type}</i>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default MovieSection;
